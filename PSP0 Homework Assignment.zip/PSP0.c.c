/***********************************************************/
/* Program Assignment: 1                               	*/  /* Name: Priyank Joshi						      */                                  
/* Date: 26/03/2015						           */                              
/* Description: The program will calculate the mean and standard deviation of a set of 'n' real numbers		 	*/
/***********************************************************/

#include <stdio.h>

int main(void)

{
	int i;
	int n;

	/* declaring arrays x (first column) and y (second column) in a one-dimensional array that can contain upto 100 elements */ 
	double x[100], y[100], a, b = 1.0, sum1 = 0.0, mean1, variance1 = 0, standard_deviation1 = 0, c, d = 1.0, sum2 = 0.0, mean2, variance2 = 0, standard_deviation2 = 0;
	
	/* Using a file pointer, that will let the program keep track of the file data.txt being accessed */
	FILE *fptr1;
	printf("Enter the number of elements = ");
	scanf("%d",&n);
	
	/* fopen and fscanf function simply opens and reads the file which returns a file pointer. In addition a FOR loop is introduced to run a number of iterations until the last element has been read and calculated */
	fptr1 = fopen("data.txt","r");
	for (i = 0; i < n; i++)
	{
		fscanf(fptr1,"%lf %lf", &x[i], &y[i]);
	}
	fclose(fptr1);

	for (i = 0; i < n; i++)
	{
		sum1 = sum1 + x[i]; 	/* As the elements in column 						one keep iterating until the 						last element, the sum is been 						calculated */
	}
		mean1 = sum1 / n;
	
	for (i = 0; i < n; i++)
	{		
		a = (x[i] - mean1)*(x[i] - mean1);
		variance1 = variance1 + a;   
	} 
		variance1 = variance1 / (n-1);

		/* while loop is introduced, so that repetition can occur and therefore setting b >= 0.001 so that we can not get a value of negative for standard deviation. square rooting a negative value will show an error in java, hence it can obly be possible when dealing with complex numbers */  
		while (b >= 0.001)
		{
			b = variance1 - (standard_deviation1 * standard_deviation1);
			standard_deviation1 = standard_deviation1 + 0.001;	
		}

	/* The same procedure for calculating mean, variance and standard deviation is implemeneted for column 2 (elements in y[i]) */

	for (i = 0; i < n; i++)
	{
		sum2 = sum2 + y[i];
	}
		mean2 = sum2 / n;
	
	for (i = 0; i < n; i++)
	{		
		c = (y[i] - mean2)*(y[i] - mean2);
		variance2 = variance2 + c;
	}
		variance2 = variance2 / (n-1);

		while (d >= 0.001)
		{
			d = variance2 - (standard_deviation2 * standard_deviation2);
			standard_deviation2 = standard_deviation2 + 0.001;	
		}

	printf("Table 1: Column 1: Mean = %lf\n", mean1);
	printf("Table 1: Column 1: Standard deviation = %lf\n", standard_deviation1);
	
	printf("Table 1: Column 2: Mean = %lf\n", mean2);
	printf("Table 1: column 2: Standard Deviation = %lf\n", standard_deviation2);

	return 0;
}
		




	
	
	



